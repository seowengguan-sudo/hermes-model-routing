OAKAI Document Reader - Windows Portable Package
===============================================

Quick Start:
  1. Extract this ZIP to C:\doc_reader_portable\
  2. Double-click run.bat to start the server
  3. Open http://localhost:8765 in your browser
  4. Upload files and process documents

Directory Structure:
  data/uploads/           - Uploaded files
  data/documents_safe/    - Safe (redacted) documents
  data/redaction_maps/    - Variable mapping files (local only)

Security:
  - All processing is 100% local
  - No LLM/API/token calls
  - PII and business-sensitive data redacted
  - Redaction map stored locally for reversible decoding
