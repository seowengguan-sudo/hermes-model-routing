@echo off
REM OAKAI Document Reader - Portable Server v2.2
echo Starting OAKAI Document Reader...
echo Access at: http://localhost:8765
echo.
echo Press Ctrl+C to stop the server
echo.
cd /d "%~dp0"
python.exe doc_reader_onefile.py
pause
