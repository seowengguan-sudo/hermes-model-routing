OAKAI Document Reader v2.2 - Fixed UI + Settings

QUICK START:
1. Extract to C:\doc_reader_portable\ (or any folder)
2. Double-click start_silent.vbs (silent) OR run.bat (console)
3. Open http://localhost:8765 in your browser

FILES:
- doc_reader_onefile.py : 1513-line engine with Settings + Business detection
- run.bat               : Windows console launcher
- run.sh                : Linux/macOS launcher
- start_silent.vbs      : Silent Windows launcher (background, no console)
- README.txt            : This file

FEATURES:
- ⚙️ Settings page: Toggle categories per client
- PII: SSN, Email, Phone, Credit Card, Bank Account
- Business: Company, Product, Director, Quote ID, Cost
- 100% local processing - no API/token calls

CATEGORIES (toggle in Settings):
  PII/Sensitive:
    - SSN (CRITICAL)
    - Email (CRITICAL)
    - Phone (CRITICAL)
    - Credit Card (CRITICAL)
    - Bank Account (CRITICAL)
  Business Sensitive:
    - Company Name (CRITICAL)
    - Product Name
    - Director Name (CRITICAL)
    - Quotation ID
    - Cost Value

USAGE:
- Click upload area to browse files, or drag-drop
- Processing results appear below with variable mapping
- Refresh button updates document list
- Redaction maps stored in data/redaction_maps/

TROUBLESHOOTING:
- Port in use? Change PORT in doc_reader_onefile.py
- Python not found? Install from python.org
- Server not responding? Try run.bat first for errors
