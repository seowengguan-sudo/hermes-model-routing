#!/bin/bash
cd "$(dirname "$0")"
python3 doc_reader_onefile.py
