@echo off
cd /d "%~dp0"
python doc_reader_onefile.py
