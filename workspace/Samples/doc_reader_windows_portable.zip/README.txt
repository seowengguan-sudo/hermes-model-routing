OAKAI Document Reader v2.2 - Final Release
==========================================

QUICK START (Windows):
1. Extract this ZIP to C:\doc_reader_portable\
2. Double-click start_silent.vbs (background, no console)
   OR double-click run.bat (shows console for debugging)
3. Open http://localhost:8765 in your browser

FILES (exactly 5):
1. doc_reader_onefile.py  - Main engine (1513 lines, all-in-one)
2. run.bat                - Windows console launcher
3. run.sh                 - Linux/macOS launcher
4. start_silent.vbs       - Silent Windows launcher (pythonw.exe)
5. README.txt             - This file

REDACTION CATEGORIES (toggle via gear icon):
  PII/Sensitive:
    - SSN              (CRITICAL) - Social Security Numbers
    - Email            (CRITICAL) - Email addresses
    - Phone            (CRITICAL) - Phone numbers
    - Credit Card      (CRITICAL) - Credit card numbers
    - Bank Account     (CRITICAL) - Bank account numbers
  Business Sensitive:
    - Company Name     (CRITICAL) - Company/organization names
    - Product Name     - Product names and model IDs
    - Director Name    (CRITICAL) - Executive personnel names
    - Quotation ID     - Reference/quote identifiers
    - Cost Value       - Monetary values and costs

KEY FIXES IN THIS VERSION:
- Portability: No hardcoded /opt/ or /home/ paths
  Dynamic venv detection based on script location
- UI fixed: mapping fetch inside try block (buttons now responsive)
- Settings page: toggle categories per client requirement
- Silent mode: start_silent.vbs uses pythonw.exe (no console window)
- mkdir with parents=True everywhere (won't fail on bare Windows)

DIRECTORIES (auto-created):
- uploads/           - Uploaded files
- documents_safe/    - Redacted output
- redaction_maps/    - Variable mappings (local only)
- data/              - All subdirectories

TROUBLESHOOTING:
- Port 8765 in use? Edit PORT in doc_reader_onefile.py
- Python not found? Install from https://python.org
- PDF processing fails? Install: pip install pypdf pillow
- Server not starting? Use run.bat first for error messages

NOTES:
- All processing is 100% local (no internet/API/token calls)
- Redaction maps stored locally, never exposed via API
- Use start_silent.vbs for background operation
- Settings persist in data/redaction_settings.json
