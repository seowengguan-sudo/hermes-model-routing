OAKAI Document Reader - Portable Package
==========================================

QUICK START:
1. Double-click run.bat (Windows) or run.sh (Linux/macOS)
2. Open your browser to: http://localhost:8765
3. Set Python executable if needed (Windows: right-click run.bat -> Edit)

REQUIREMENTS:
- Python 3.10 or higher (install from python.org)
- Pillow (PIL) for image handling
- PyPDF for PDF processing (optional)

The server runs locally - NO internet, NO API tokens, NO external LLM calls.
All redaction is 100% local with reversible variable mapping.

FILES:
- doc_reader_onefile.py : OAKAI anonymization engine (self-contained)
- run.bat : Windows launcher
- run.sh : Linux/macOS launcher
- README.txt : This file

TROUBLESHOOTING:
- If port 8765 is in use, modify the port in doc_reader_onefile.py
- If Python isn't found, install from https://python.org
- If packages are missing: pip install pillow pypdf

For support, check the OAKAI settings page at http://localhost:8765 (gear icon).
