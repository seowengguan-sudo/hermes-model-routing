#!/bin/bash
# OAKAI Document Reader - Portable Launcher (Linux/macOS)
echo "Starting OAKAI Document Reader..."
echo ""
echo "Checking Python..."
python3 --version
echo ""
echo "Starting server on http://localhost:8765"
echo "Press Ctrl+C to stop"
echo ""
python3 doc_reader_onefile.py
