OAKAI Document Reader - Portable Package (Windows)
===================================================

VERSION: 2.1 - With Settings & Business-Sensitive Redaction
Last Updated: 2026-08-16

QUICK START:
1. Extract this ZIP file to any folder on your Windows machine
   (e.g., C:\doc_reader_portable\)
2. Double-click run.bat to start the server
   OR double-click start_silent.vbs for silent/background start
3. Open your browser to: http://localhost:8765

FILES IN THIS PACKAGE:
- doc_reader_onefile.py : OAKAI anonymization engine (self-contained, 1522 lines)
- run.bat               : Windows launcher (shows console for debugging)
- run.sh                : Linux/macOS launcher
- start_silent.vbs      : Windows background launcher (no console window)
- README.txt            : This file

REQUIREMENTS:
- Python 3.10 or higher (download from https://python.org)
- Pillow (optional, for PDF/image processing)

FEATURES:
- Full PII redaction: SSN, Email, Phone, Credit Card, Bank Account
- Business-sensitive redaction: Company names, Product names,
  Director names, Quotation IDs, Cost values
- Settings page (click gear icon ⚙️): Enable/disable categories per client
- Supports: PDF, Word (.docx), Excel (.xlsx), PPTX, TXT, CSV, HTML, JSON, MD
- Professional OAKAI-branded UI with dark theme
- Zero external LLM/API calls — 100% local processing
- Reversible variable mapping stored locally

DIRECTORY STRUCTURE:
- uploads/         - Uploaded files saved here
- documents_safe/  - Redacted documents with {VARIABLE} placeholders
- redaction_maps/  - Variable→original mapping (local only, never exposed)
- redaction_settings.json - Your saved category settings

USAGE:
1. After starting server, open http://localhost:8765
2. Click "Choose File" or drag files onto the upload area
3. View redacted document and mapping in the UI
4. Click ⚙️ Settings to toggle which categories to redact
5. Click 🔄 Refresh to update document list

TROUBLESHOOTING:
- Port 8765 in use? Edit doc_reader_onefile.py, change PORT = 8765
- Python not found? Install from https://python.org, add to PATH
- Missing Pillow? Run: pip install pillow
- Server not responding? Check Windows Firewall (port 8765)

NOTE FOR WINDOWS USERS:
- Use start_silent.vbs for background operation without console window
- The server creates data/ folder locally for uploads and maps
- All redaction maps are stored locally — no cloud sync
