Set WshShell = CreateObject("WScript.Shell")
strScriptDir = Left(WScript.ScriptFullName, Len(WScript.ScriptFullName) - Len(WScript.ScriptName))
strScriptPath = strScriptDir & "doc_reader_onefile.py"
Set objFSO = CreateObject("Scripting.FileSystemObject")
strUser = WshShell.ExpandEnvironmentStrings("%USERNAME%")
pythonwPaths = Array( _
    "C:\Users\" & strUser & "\AppData\Local\Programs\Python\Python312\pythonw.exe", _
    "C:\Users\" & strUser & "\AppData\Local\Programs\Python\Python311\pythonw.exe", _
    "C:\Users\" & strUser & "\AppData\Local\Programs\Python\Python310\pythonw.exe" _
)
strPython = "pythonw.exe"
For Each py In pythonwPaths
    If objFSO.FileExists(py) Then
        strPython = py
        Exit For
    End If
Next
WshShell.CurrentDirectory = strScriptDir
WshShell.Run """" & strPython & """ """ & strScriptPath & """", 0, False
