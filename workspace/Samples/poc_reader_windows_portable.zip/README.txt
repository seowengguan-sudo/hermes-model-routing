OAKAI Document Reader v2.3 - With Live Restart (POC Edition)
============================================================

QUICK START (Windows):
1. Extract this ZIP to C:\doc_reader_portable\
2. Double-click start_silent.vbs (background, no console)
   OR double-click run.bat (shows console for debugging)
3. Open http://localhost:8765 in your browser

FILES (exactly 6, flat structure):
1. doc_reader_onefile.py   - Main engine with Settings + Live Restart
2. run.bat                 - Windows console launcher
3. run.sh                  - Linux/macOS launcher
4. start_silent.vbs        - Silent Windows launcher (pythonw.exe)
5. restart_helper.vbs      - Restart helper (auto-launched by server)
6. README.txt              - This file

REDACTION CATEGORIES (toggle via Settings gear icon):
  PII/Sensitive:
    - SSN              (CRITICAL) - Social Security Numbers
    - Email            (CRITICAL) - Email addresses
    - Phone            (CRITICAL) - Phone numbers
    - Credit Card      (CRITICAL) - Credit card numbers
    - Bank Account     (CRITICAL) - Bank account numbers
  Business Sensitive:
    - Company Name     (CRITICAL) - Company/organization names
    - Product Name     - Product names and model IDs
    - Director Name    (CRITICAL) - Executive personnel names
    - Quotation ID     - Reference/quote identifiers
    - Cost Value       - Monetary values and costs

=== LIVE RESTART WORKFLOW ===
When you make changes to doc_reader_onefile.py:

1. Edit/save the file in your local folder
2. In your browser, click the restart button (arrows icon in header)
3. The server will:
   a) Send HTTP response (you'll see "Restarting...")
   b) Spawn restart_helper.vbs which kills the old pythonw.exe process
   c) Relaunch start_silent.vbs which starts the new code
   d) Auto-reload the page when the server is back up

NOTE: Two buttons in the header:
  Refresh  = Reloads document list (no restart)
  Restart  = Kills + restarts server process (use after code changes)

KEY FEATURES:
- No hardcoded /opt/ or /home/ paths (portable)
- Live restart: Update code, click restart button, auto-reloads
- Settings page: Toggle categories per client requirement
- Silent mode: start_silent.vbs uses pythonw.exe

DIRECTORIES (auto-created in data/ next to this script):
- uploads/           - Uploaded files
- documents_safe/    - Redacted output
- redaction_maps/    - Variable mappings (local only, never exposed)
- data/              - All subdirectories

TROUBLESHOOTING:
- Port 8765 in use? Edit PORT in doc_reader_onefile.py and restart
- Python not found? Install from python.org (3.10+ required)
- PDF processing slow? Install pypdf + pillow for faster extraction
- Server won't restart? Run run.bat first for error messages
- Stuck? Kill all pythonw.exe in Task Manager, then re-run start_silent.vbs

NOTES:
- All processing is 100% local (no internet/API/token calls)
- Redaction maps stored locally, never exposed via API
- Use start_silent.vbs for background operation
- Settings persist in data/redaction_settings.json
- Restart button only works on Windows (uses restart_helper.vbs)
