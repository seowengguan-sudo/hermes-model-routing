@echo off
REM OAKAI Document Reader - Portable Launcher
REM Double-click to run the OAKAI server locally

echo Starting OAKAI Document Reader...
echo.

REM Check if Python is available
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Please install Python 3.10+ from python.org
    echo After installing, run this batch file again.
    pause
    exit /b 1
)

echo Using:
python --version

REM Install required packages if needed
echo.
echo Checking dependencies...
pip install -q pillow pypdf 2>nul
if errorlevel 1 (
    echo Warning: Some packages may be missing. Install with: pip install pillow pypdf
)

REM Start the server
echo.
echo Starting server on http://localhost:8765
echo Press Ctrl+C to stop
echo.

python doc_reader_onefile.py

pause
