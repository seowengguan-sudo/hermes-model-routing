Set WshShell = CreateObject("WScript.Shell")

' OAKAI Document Reader - Silent Launcher
' Launches the server without a console window for clean Windows operation
' Place in same folder as doc_reader_onefile.py

strScriptDir = Left(WScript.ScriptFullName, Len(WScript.ScriptFullName) - Len(WScript.ScriptName))
strScriptPath = strScriptDir & "doc_reader_onefile.py"

' Try to find pythonw.exe (background, no console)
Set objFSO = CreateObject("Scripting.FileSystemObject")
strUser = WshShell.ExpandEnvironmentStrings("%USERNAME%")

pythonwPaths = Array( _
    "pythonw.exe", _
    "C:\Users\" & strUser & "\AppData\Local\Programs\Python\Python312\pythonw.exe", _
    "C:\Users\" & strUser & "\AppData\Local\Programs\Python\Python311\pythonw.exe", _
    "C:\Users\" & strUser & "\AppData\Local\Programs\Python\Python310\pythonw.exe", _
    "C:\Python312\pythonw.exe", _
    "C:\Python311\pythonw.exe" _
)

strPython = ""
For Each py In pythonwPaths
    If InStr(py, "\") > 0 Then
        If objFSO.FileExists(py) Then
            strPython = py
            Exit For
        End If
    Else
        ' Check if command is available in PATH
        ' (pythonw.exe will be found by system if in PATH)
        strPython = py
    End If
Next

If strPython = "" Then
    ' Fall back to python.exe
    strPython = "python.exe"
End If

' Launch server silently (window style 0 = hidden)
WshShell.CurrentDirectory = strScriptDir
WshShell.Run """" & strPython & """ """ & strScriptPath & """", 0, False
