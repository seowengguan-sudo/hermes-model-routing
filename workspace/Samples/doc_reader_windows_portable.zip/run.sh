#!/bin/bash
# OAKAI Document Reader - Portable Server (Linux/macOS/WSL2) v2.2
echo "Starting OAKAI Document Reader..."
echo "Access at: http://localhost:8765"
echo ""
cd "$(dirname "$0")"

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "ERROR: python3 not found in PATH"
    echo "Please install Python 3.10+ from https://python.org"
    exit 1
fi

python3 doc_reader_onefile.py
